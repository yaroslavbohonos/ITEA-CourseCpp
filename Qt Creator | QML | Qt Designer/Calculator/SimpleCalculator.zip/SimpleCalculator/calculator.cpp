#include "calculator.h"
#include "./ui_calculator.h"

#include "QChar"

Calculator::Calculator(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Calculator)
{
    ui->setupUi(this);
}

Calculator::~Calculator()
{
    delete ui;
}


void Calculator::on_pushButton_clicked()
{
    double index1 = ui->spinBox->value();
    double index2 = ui->spinBox_2->value();
    QString symbol = ui->comboBox->currentText();
    QString display = ui->lineEdit->displayText();

    if (symbol == "+")
    {
        display = QString::number(index1 + index2);
    }
    else if (symbol == "-")
    {
        display = QString::number(index1 - index2);
    }
    else if (symbol == "\u00F7") // Unicode value for '÷'
    {
        display = QString::number(index1 / index2);
    }
    else if (symbol == "x")
    {
        display = QString::number(index1 * index2);
    }
    else if (symbol == "%")
    {
        display = QString::number(int(index1) % int(index2));
    }

    ui->lineEdit->setText(display);
}

