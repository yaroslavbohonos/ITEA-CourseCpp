#include "mainwindow.h"
#include "./ui_mainwindow.h"

#include "QString"
#include "QLineEdit"
#include "QMessageBox"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->lineEdit->setToolTip("Search Field");
    ui->textEdit->setToolTip("Text");
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    QString searchString = ui->lineEdit->text();
    QTextDocument *document = ui->textEdit->document();

    if (searchString.isEmpty() || document->isEmpty())
    {
        QMessageBox::information(this, tr(""),
                                 tr("Empty Search Field or Text is empty.\nPlease enter a word and click Find."));
    }
    else
    {
        QTextCursor highlightCursor(document);
        QTextCursor cursor(document);

        cursor.beginEditBlock();

        QTextCharFormat plainFormat(highlightCursor.charFormat());
        QTextCharFormat colorFormat = plainFormat;
        colorFormat.setForeground(Qt::red);

        int counterWords = 0;
        while (!highlightCursor.isNull() && !highlightCursor.atEnd()) {
            highlightCursor = document->find(searchString, highlightCursor,
                                             QTextDocument::FindWholeWords);
            if (!highlightCursor.isNull()) {
                counterWords++;
                highlightCursor.movePosition(QTextCursor::WordRight,
                                             QTextCursor::KeepAnchor);
                highlightCursor.mergeCharFormat(colorFormat);
            }
        }
        cursor.endEditBlock();
        QMessageBox::information(this, "The word - ", QString(ui->lineEdit->text() + " was found " + QString::number(counterWords) + " times"));
    }
}

